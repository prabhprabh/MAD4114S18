//
//  ViewController.swift
//  notebook
//
//  Created by MacStudent on 2018-07-16.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    //MARK: outlets
     var myContext : NSManagedObjectContext!
    
    @IBOutlet weak var tbNotebookName: UITextField!
    @IBOutlet weak var tbPage: UITextField!
    @IBOutlet weak var showAll: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        myContext = appDelegate.persistentContainer.viewContext
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

//MARK: actions
    @IBAction func addNotebook(_ sender: UIButton) {
        //TODO: add code here
        print("added")
        
        //validation
        //...makem sure textbox is empty
        
        let x = tbNotebookName.text!
        if(x.isEmpty){
            print("plase enter a name")
            return
        }
        
        let notebook = Notebook (context: myContext!)
        notebook.title = tbNotebookName.text!
        notebook.dateCreated = Date()
        
        do {
            try myContext!.save()
            
            }
          
        catch{
            print("Error saving data into database")
        }
        
    }

    @IBAction func addPagePressed(_ sender: UIButton) {
        
        let page = Page(context: myContext)
        page.text = tbPage.text!
        page.dateAdded = Date()
        
        
        let x = tbNotebookName.text!  //get nb name from ui
        
        if(x.isEmpty){
            print("plase enter a name")    //validation
            return
        }
        //get the notebook you want to add the page to
        //...let notebook = getNotebook(name:"______")
        let n = getNotebook(name:x)
        
        
        //validation---check if nb exists
        if(n == nil){
            print("nb does not exist")
            return
        }
        
        //associate page to that particular nb
        
        //page.notebook = _______
        page.notebook = n
        
        do {
            try myContext!.save()
            print("page saved")
        }
            
        catch{
            print("Error saving data into database")
        }
        
    }
    
    func getNotebook(name:String) -> Notebook?{
        //1.fetch nb with this name from core data
        let fetchRequest : NSFetchRequest<Notebook> = Notebook.fetchRequest()
        
        
        //2. add a where to sql statement
        fetchRequest.predicate = NSPredicate(format: "title = %@", name)
        
        //add a limit
        fetchRequest.fetchLimit = 1
        //select * from notebook where "name = swift" limit 1
        
        //get results from db
        do{
           let row = try myContext.fetch(fetchRequest)
            
            if (row.count > 0){
                return row[0]
            }else{
                //if nothing found
                return nil
            }
        }catch{
            print("error")
        }
        //return it
        return nil
        
    }
    @IBAction func showAll(_ sender: UIButton) {
        //get name of nb
        let x = tbNotebookName.text!  //get nb name from ui
       // let n = getNotebook(name:x)
        
        if(x.isEmpty){
            print("plase enter a name")    //validation
            return
        }
        
        //query db for all pages belonging to nb
        let fetchRequest : NSFetchRequest<Page> = Page.fetchRequest()
        
        
        //2. add a where to sql statement
         let n = getNotebook(name:x)
        fetchRequest.predicate = NSPredicate(format: "notebook = %@", n!)
        
        if(n == nil){
            print("nb does not exist")
            return
        }
        
        //get results from db
        do{
            let rows = try myContext.fetch(fetchRequest)
            
            for row in rows{
                print("++++++")
                print(row.text!)
                print("++++++")
            }
        }catch{
            print("error")
        }
       
        
        //output to screen
        
        
        
    }
    
}
