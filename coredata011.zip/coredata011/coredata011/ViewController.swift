//
//  ViewController.swift
//  coredata011
//
//  Created by MacStudent on 2018-07-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
        //1. create db connection variable
        //$db->$conn (in php)
        //$mysql->conn($db) (in php)
        
        //core db
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext

        
        //2. craete row in table
        //which table do i intaract with?(user)
        let userEntity = NSEntityDescription.entity(forEntityName: "User", in: managedContext)!
        
        
        //craete row in table
        //=====create new user object
        let user = NSManagedObject(entity: userEntity, insertInto: managedContext)
        
        //=====set properties to object
        user.setValue("Jigisha Patel", forKey: "name")
        user.setValue("Jigisha@gmail.com", forKey: "email")
        user.setValue(2, forKey: "kids")
        //make a date var
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let date = formatter.date(from:"2015-05-23")
        
        
        user.setValue(date, forKey: "dob")
        print(user)
        
        
        //3.save row in table
        do{
        try managedContext.save()
        }catch{
        print("error found")
        }
        print("Done")
        
        //4.show
        //create select * from table
      let userfetch = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        //run sql
        do{
            print("showing results")
        let users = try managedContext.fetch(userfetch)
            print(users)
        }catch{
            print("error found while fetching")
        }
        
       
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

