//
//  User+CoreDataClass.swift
//  coredata011
//
//  Created by MacStudent on 2018-07-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
