//
//  ViewController.swift
//  NoteTakingApp
//
//  Created by robin on 2018-07-09.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    var managedContext: NSManagedObjectContext?
    
    @IBOutlet weak var noteText: UITextField!
    
    var groceryList: [GroceryListItem] = []
    
    @IBOutlet weak var textView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        //crete connectioin with db
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        managedContext = appDelegate.persistentContainer.viewContext
        
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
   

    @IBAction func addNote(_ sender: Any) {
        print("clicked!")
        
        // check if textbox is empty
        guard let x = noteText.text , x != "" else {
            print("textbox is empty")
            return
        }
//.......................................=========================================================================
        //create new coredata groceryItem obj
        
        let groceryItemEntity = NSEntityDescription.entity(forEntityName: "GroceryItem", in: managedContext!)
        let item = NSManagedObject(entity: groceryItemEntity!, insertInto: managedContext!)
        
        //set properties of core data grocery item
        item.setValue(noteText.text, forKey: "itemName")   //from text box
        item.setValue(Date(), forKey: "dateAdded")  //Date() ..automatically creates todays date
        
        //save obj to db
        do{
            try managedContext!.save()
        }catch{
            print("error found")
        }
        print("Done")
        
        /*
        // create a note and save to system
        let item : GroceryListItem = GroceryListItem(item:x)
        groceryList.append(item);
         */
 //.......................................=========================================================================
        // clear the textbox
        noteText.text = ""
        
        // create an alert box to show user
        
        // -- make an alert
        let alert = UIAlertController(title: "Save Complete", message: "Your item was saved!", preferredStyle: .alert)
        
        // -- add a button
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil))
        
        // -- show the popup
       // self.present(------, animated: true, completion: nil)
        self.present(alert, animated: true, completion: nil)
       
        
    }

    @IBAction func showAll(_ sender: Any) {
        
        //make a fetch request
        //- telling ios whuich tbale you want--- "GroceryItem"
        //-tell ios which sql query you want---- (select* bydefalut)
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "GroceryItem")
        
        //send query to db
        do{
            print("showing results")
            let rows = try managedContext!.fetch(fetchRequest)
            //process and display
            for item in rows {
                let x = item as! GroceryItem
                print("\(x.dateAdded): \(x.itemName)")
            }
        }catch{
            print("error found while fetching")
        }
        
       
    }
}

