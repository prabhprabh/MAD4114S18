WeatherApp!

Libraries:

* AlamoFire  (making an network call)
* SwiftyJSON  (Parsing json)
* Chameleon (UI Nonsense)

![alt text](screenshot.png)


