//
//  TableViewControllerTwo.swift
//  notebook
//
//  Created by MacStudent on 2018-07-17.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData

class TableViewControllerTwo: UITableViewController {

    
    var myContext : NSManagedObjectContext!
    // create a data source
    var nb : [Page] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        myContext = appDelegate.persistentContainer.viewContext
        
        getAllNb()

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return nb.count
    }
    
    func getAllNb(){
        let x = "prabh"
        let n = getNotebook(name:x)
        
        
        //query db for all pages belonging to nb
        let fetchRequest : NSFetchRequest<Page> = Page.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "notebook = %@", n!)
        
        //get results from db
        do{
            nb = try myContext.fetch(fetchRequest)
            
            for row in nb{
                print("++++++")
                print(row.text!)
                print(row.dateAdded!)
                print("++++++")
            }
        }catch{
            print("error")
        }
    }
        
        func getNotebook(name:String) -> Notebook?{
            //1.fetch nb with this name from core data
            let fetchRequest : NSFetchRequest<Notebook> = Notebook.fetchRequest()
            
            
            //2. add a where to sql statement
            fetchRequest.predicate = NSPredicate(format: "title = %@", name)
            
            //add a limit
            fetchRequest.fetchLimit = 1
            //select * from notebook where "name = swift" limit 1
            
            //get results from db
            do{
                let row = try myContext.fetch(fetchRequest)
                
                if (row.count > 0){
                    return row[0]
                }else{
                    //if nothing found
                    return nil
                }
            }catch{
                print("error")
            }
            //return it
            return nil
            
        }
    

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)

        // Configure the cell...
        cell.textLabel?.text = nb[indexPath.row].text
        
        return cell
    }
    
    
    // what should happen when you click on stuff
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // show the row number
        print(indexPath.row)
        
        // show what's actually in the row
        print(nb[indexPath.row])
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
