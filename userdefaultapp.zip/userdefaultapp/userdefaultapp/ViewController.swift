//
//  ViewController.swift
//  userdefaultapp
//
//  Created by MacStudent on 2018-07-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //play with userdefault here
        
        
        //tell ios you want to use Userdeafaults (localstorage from web)
        let defaults = UserDefaults.standard
        
        //show what is in dictionary by default
        print(defaults.dictionaryRepresentation())
        
        //value first then key...
        //string
        defaults.set("prabh", forKey: "studentname");
        
        //boolean
        defaults.set(true, forKey: "isStudent");
        
        //double
        defaults.set(800.98, forKey: "hourlyRate");
        
        //array
        let courcesLearned = ["iOs","Android","Swift","Java","Database"]
        defaults.set(courcesLearned, forKey: "courses")
        
        //dictionary
        let student = ["name":"Prabhjot Kaur", "id":"C0730124","program" : "MADT","sem":"2nd"]
        defaults.set(student, forKey:"student")
        
        
        //print whole dictionary
        //print(defaults.dictionaryRepresentation())
        
        //get a specific thing from dictionary
        let x = defaults.double(forKey: "hourlyRate")
        print(x)
        
        print("IS prabh a student..??")
        let y = defaults.bool(forKey: "isStudent")
        print(y)
        
        print("what is her full name")
        let name = defaults.string(forKey: "studentname")
        print(name!)
        
        print("what courses she has learned..??")
        let c = defaults.array(forKey: "courses") as! [String]
       //to print a particular thing out of array
        print(c[0])
        //to print whole array
        print(c)
        
        print("Who is her student")
        let stu = defaults.dictionary(forKey: "student") as! Dictionary<String,String>
        print(stu)
        //add some things to user defaults
        
        
        //print / get stuff from userdefaults
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

