//
//  ViewController.swift
//  WeatherAppPretty
//
//  Created by robin on 2018-07-15.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Alamofire            // 1. Import AlamoFire and SwiftyJson
import SwiftyJSON

import ChameleonFramework         // optional - used to make colors pretty

import CoreLocation



class ViewController: UIViewController, CLLocationManagerDelegate {

    // --------------------------------------------
    // MARK: User interface outlets
    // --------------------------------------------
    @IBOutlet weak var labelLocation: UILabel!
    @IBOutlet weak var labelDate: UILabel!
    @IBOutlet weak var labelTemp: UILabel!
    @IBOutlet weak var imageWeatherIcon: UIImageView!
    @IBOutlet weak var labelHumidity: UILabel!
    @IBOutlet weak var labelVisibility: UILabel!
    @IBOutlet weak var labelRain: UILabel!
    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var weatherIcon: UIImageView!
    
    var myLocations : [CLLocationCoordinate2D] = []
    
    // Make a CoreLocation variable
    var manager : CLLocationManager!
    
    
    // --------------------------------------------
    // TODO: url variables
    // --------------------------------------------
    let URL = "https://api.darksky.net/forecast/252a5f0f6be2fab9856294c15e29987d/28.7041,-77.1025?exclude=minutely,hourly,daily,alerts,flags&units=ca"
    //let LOCATION = "28.7041,77.1025"
    //let PARAMS = "?exclude=minutely,hourly,daily,alerts,flags&units=ca"

    
    // --------------------------------------------
    // TODO: Add location variables
    // --------------------------------------------
    
    // put your location variables here
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // UI NONSENSE - Make a gradient background using Chameleon
        let colors:[UIColor] = [
            UIColor(hexString:"#F27121")!,
            UIColor(hexString:"#E94057")!,
            UIColor(hexString:"#8A2387")!
        ]
        view.backgroundColor = UIColor(gradientStyle:UIGradientStyle.topToBottom, withFrame:view.frame, andColors:colors)

        
        // TODO: Get the current location
        
/////////////////////////////////////////// copy paste from map bitbucket
        // 1. Setup your CoreLocation variable
        self.manager = CLLocationManager()
        self.manager.delegate = self
        
        // 2. Tell ios how accurate you want the location to be
        self.manager.desiredAccuracy = kCLLocationAccuracyBest
        
        // 3. Ask the user for permission to get their location
        self.manager.requestAlwaysAuthorization()
        
        // 4. Get the user's location
        self.manager.startUpdatingLocation()
        //  do this later
      
        
        
        // TODO: Get the weather
        getWeather(url:URL)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func locationChangePressed(_ sender: UIBarButtonItem) {
        
        
        let lat = manager.location?.coordinate.latitude
        let long = manager.location?.coordinate.longitude
        
        let loc = "heyyyyy\(lat!),\(long!)"
        print(loc)
        
        
        
        
        
    }
    
    @IBAction func refreshWeather(_ sender: Any) {
        // TODO: Refresh the weather data.
        print("refresh weather button pushed")
        
        getWeather(url:URL)
        
    }

    
    func getWeather(url:String) {
        // Build the URL:
        
        
        let url = "https://api.darksky.net/forecast/252a5f0f6be2fab9856294c15e29987d/28.7041,-77.1025?exclude=minutely,hourly,daily,alerts,flags&units=ca"
        print(url)
        
        
        
        Alamofire.request(url, method: .get, parameters: nil).responseJSON {
            
            (response) in
            
            if response.result.isSuccess {
                if let dataFromServer = response.data {
                    
        
                    do {
                        let json = try JSON(data: dataFromServer)
                        
                        // TODO: Parse the json response
                           print(json)
                        
                        
                        // TODO: Display the results
                        let currently = json["currently"].dictionaryValue
                        let date = currently["time"]!.doubleValue
                        var humidity = currently["temperature"]!.doubleValue
                        let summary = currently["summary"]!.stringValue
                        var rainchance = currently["precipProbability"]!.doubleValue
                        let windspeed = currently["windSpeed"]!.doubleValue
                        let temp = currently["apparentTemperature"]!.doubleValue
                        
                        //humidity = humidity! * 100
                        rainchance = rainchance * 100
                       // labelHumidity.text = humidity
                        
                        
                        
                        print(currently)
                        print(date)
                        print("\(String(format:"%.0f", humidity))%")
                        print(summary)
                        print("\(String(format:"%.0f", rainchance))%")
                        print(windspeed)
                        print(temp)
                        
                        self.labelDate.text = ("\(date)")
                        self.labelHumidity.text = ("\(String(format:"%.0f", humidity))%")
                        self.labelStatus.text = ("\(summary)")
                        self.labelRain.text = ("\(String(format:"%.0f", rainchance))%")
                        self.labelVisibility.text = ("\(windspeed)km/h")
                        self.labelTemp.text = ("\(temp)")
                        
                        
                        
                        
                        
                        //date formating
                        // 1. convert from unix time to human readable time
                        var dateFromTimeStamp = Date(timeIntervalSince1970: date)
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.timeZone = TimeZone(abbreviation: "EST")
                        
                        // 2. format the date  - Wednesday, July 25, 2018
                        dateFormatter.dateFormat = "EEEE, MMM d, yyyy"
                        let dayString = dateFormatter.string(from:dateFromTimeStamp)
                        
                        // update the navigation bar
                        self.title = dayString
                        
                        // 3. format the time - as 8:52pm
                        dateFormatter.dateFormat = "h:mm a"
                        let timeString = dateFormatter.string(from:dateFromTimeStamp)
                        
                        // update the label
                        self.labelDate.text = "Last Updated \(timeString)"

                    }
                    catch {
                        print("error")
                    }
                    
                }
                else {
                    print("Error when getting JSON from the response")
                }
            }
            else {
                // 6. You got an error while trying to connect to the API
                print("Error while fetching data from URL")
            }
            
        }
        

    }
    
    
    // --------------------------------------------
    // TODO: Add location
    // --------------------------------------------
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // this function gets called every time the person's location changes
        print("location updated!")

        let lat = manager.location?.coordinate.latitude
        let long = manager.location?.coordinate.longitude
        
        let loc = "\(lat),\(long)"
        print(loc)
        
    }
    

}

