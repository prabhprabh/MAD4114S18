//
//  ViewControllerTwo.swift
//  FBtest
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewControllerTwo: UIViewController {

  
    @IBOutlet weak var usernamew: UITextField!
    @IBOutlet weak var msg: UITextField!
    
    
    var db:DatabaseReference!
    
    @IBOutlet weak var textarea: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //setup fb var
        self.db = Database.database().reference()
       // watchForChanges()
       watchForAdded()
       // watchForDeleted()
    }

    @IBAction func addFB(_ sender: UIButton) {
        
        let user = usernamew.text!
        let msg = self.msg.text!
        
        let x = ["user":user,"text":msg]
        self.db.child("chat").childByAutoId().setValue(x)
        
    }
    
    func watchForAdded(){
        self.db.child("chat").observe(DataEventType.childAdded, with: {(snapshot) in
            
            let x = snapshot.value as! Dictionary<String,String>
            
            
            let u = x["user"]
            let m = x["text"]
            
            self.textarea.text.append(x["user"]!)
            self.textarea.text.append(" says \n")
            self.textarea.text.append(x["text"]!)
            self.textarea.text.append("\n")
            
        })
    }
    
    
    
    /*
    
    func watchForChanges(){
        self.db.child("monday").observe(DataEventType.childChanged, with: {(snapshot) in
            
            let x = snapshot.value as! String
            
            self.textarea.text.append("something is changed \n")
            self.textarea.text.append(x)
            self.textarea.text.append("\n")
            
        })
    }
    
    func watchForAdded(){
        self.db.child("monday").observe(DataEventType.childAdded, with: {(snapshot) in
            
            let x = snapshot.value as! String
            
            self.textarea.text.append("something is added \n")
            self.textarea.text.append(x)
            self.textarea.text.append("\n")
            
        })
    }
    
    func watchForDeleted(){
        self.db.child("monday").observe(DataEventType.childRemoved, with: {(snapshot) in
            
            let x = snapshot.value as! String
            
            self.textarea.text.append("something is delete \n")
            self.textarea.text.append(x)
            self.textarea.text.append("\n")
            
        })
    }
 
 */
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
