//
//  ViewController.swift
//  FBtest
//
//  Created by robin on 2018-07-19.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

import CoreData


class ViewController: UIViewController {
    
    
    @IBOutlet weak var textview: UITextField!
    var db:DatabaseReference!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        //setup fb var
        self.db = Database.database().reference()
        
        
        /*
        self.db.setValue(12)
        
        //add some keys
        let x:[String:Any] = ["age":25, "color":"blue"]
        self.db.setValue(x)
        
        //add new node
        self.db.child("cars").setValue(55)
         self.db.child("name").setValue("prabh")
         self.db.child("msg").setValue("love u g")
        
        //add nodes inside another node
        let y:[String:Any] = ["name":"kadeem","dept":"CPCT"]
        self.db.child("instructions").setValue(y)
        
        
        //create random id
        self.db.childByAutoId().setValue("hello World")
        self.db.childByAutoId().setValue("Apple")
        self.db.childByAutoId().setValue("Mango")
        self.db.childByAutoId().setValue("Banana")
        self.db.childByAutoId().setValue("Donut")
        self.db.childByAutoId().setValue("Carrot")
        */
        
        
        //tell fb we wannna know when things change
        //==when data change
        //==added//delete//update
        
        watchForChange()
        
    }
    
    func watchForChange(){
        self.db.child("todos").observe(DataEventType.childAdded, with:{
            //do something
            (snapshot) in
            
            print("added")
            let x = snapshot.value
            print(x)
            print("=====")
            
            
            
            
        })
        }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addTaskPressed(_ sender: UIButton) {
        print("pressed")
        
        //fet text from ui
        let x = textview.text
        
        //validation
        if(x?.isEmpty == true){
            return
        }
        //put text in fb
        self.db.child("todos").childByAutoId().setValue(x)
    }
    
}

