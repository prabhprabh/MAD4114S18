//
//  ViewController.swift
//  fartapp
//
//  Created by MacStudent on 2018-07-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    //variable and outlets
    
    //create a sound player variable
    var audioPlayer : AVAudioPlayer?
    
    
    
    //deafult functions
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

//actions
    @IBAction func playfart(_ sender: UIButton) {
        
        //tell system where to find file__creating a variable to represent file locaiton
        
        //copying it outside to make it default sound
         var url = Bundle.main.url(forResource:"fart-03",withExtension:"mp3")
        
        
        if (sender.tag == 1){
            print("wet fart")
            url = Bundle.main.url(forResource:"fart-03",withExtension:"mp3")
        }else if(sender.tag == 2){
            print("squeaky fart")
            url = Bundle.main.url(forResource:"fart-squeak-01",withExtension:"mp3")
        }else if(sender.tag == 3){
            print("lentis fart")
            url = Bundle.main.url(forResource:"fart-06",withExtension:"mp3")
    }
        
        
 
        
       
        do{
             //tell audio player location of file
            audioPlayer = try AVAudioPlayer(contentsOf: url!)
            
            
            //play sound
            audioPlayer?.play()
        }catch{
            //deal with error
            print("error while playing audio")
        }
 
    }
   
   
}

